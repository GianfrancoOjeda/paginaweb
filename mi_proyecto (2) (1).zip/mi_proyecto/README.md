#Flatfy - Theme | New Version!

##Responsive Mobile & Flat Design 
Own Carousel & Bootstrap Framework CSS 
Font Icon Svg & Animate

Theme made by [Andrea Galanti](http://www.andreagalanti.it/flatfy.php)